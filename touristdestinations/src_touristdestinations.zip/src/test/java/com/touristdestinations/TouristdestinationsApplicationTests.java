package com.touristdestinations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TouristdestinationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
