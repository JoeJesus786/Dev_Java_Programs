package sample;

public class Samp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
