package fninterface;

interface Mycosumer
{}
public class ConsumerFninterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
